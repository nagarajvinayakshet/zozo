/*
 * Copyright 2013 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package kannada.bhava.geete;

import java.util.Locale;
import java.util.Random;

import android.app.Activity;
import android.app.Fragment;
import android.app.FragmentManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Configuration;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.support.v4.app.ActionBarDrawerToggle;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.telephony.TelephonyManager;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;

/**
 * This example illustrates a common usage of the DrawerLayout widget in the
 * Android support library.
 * <p/>
 * <p>
 * When a navigation (left) drawer is present, the host activity should detect
 * presses of the action bar's Up affordance as a signal to open and close the
 * navigation drawer. The ActionBarDrawerToggle facilitates this behavior. Items
 * within the drawer should fall into one of two categories:
 * </p>
 * <p/>
 * <ul>
 * <li><strong>View switches</strong>. A view switch follows the same basic
 * policies as list or tab navigation in that a view switch does not create
 * navigation history. This pattern should only be used at the root activity of
 * a task, leaving some form of Up navigation active for activities further down
 * the navigation hierarchy.</li>
 * <li><strong>Selective Up</strong>. The drawer allows the user to choose an
 * alternate parent for Up navigation. This allows a user to jump across an
 * app's navigation hierarchy at will. The application should treat this as it
 * treats Up navigation from a different task, replacing the current task stack
 * using TaskStackBuilder or similar. This is the only form of navigation drawer
 * that should be used outside of the root activity of a task.</li>
 * </ul>
 * <p/>
 * <p>
 * Right side drawers should be used for actions, not navigation. This follows
 * the pattern established by the Action Bar that navigation should be to the
 * left and actions to the right. An action should be an operation performed on
 * the current contents of the window, for example enabling or disabling a data
 * overlay on top of the current content.
 * </p>
 */
public class MainActivity extends Activity {
	private DrawerLayout mDrawerLayout;
	private ListView mDrawerList;
	private ActionBarDrawerToggle mDrawerToggle;

	private CharSequence mDrawerTitle;
	private CharSequence mTitle;
	private String[] mPlanetTitles;
	static MediaPlayer mediaPlayer;
	private static InterstitialAd mInterstitialAd;
	private boolean setinpause;
	static boolean drawerclose;
	static TextToSpeech t1;
	private ResponseReceiver receiver;

	public class ResponseReceiver extends BroadcastReceiver {
		public static final String ACTION_RESP = "android.intent.action.PHONE_STATE";

		@Override
		public void onReceive(Context context, Intent intent) {
			// TODO Start a dialogue if message indicates successfully posted to
			// server
			String state = intent.getStringExtra(TelephonyManager.EXTRA_STATE);
			if (state.equals(TelephonyManager.EXTRA_STATE_RINGING)) {
				if (mediaPlayer != null && mediaPlayer.isPlaying()) {
					mediaPlayer.stop();
				}

			}
		}
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		mTitle = mDrawerTitle = getTitle();
		mPlanetTitles = getResources().getStringArray(R.array.planets_array);
		mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
		mDrawerList = (ListView) findViewById(R.id.left_drawer);
		IntentFilter filter = new IntentFilter(ResponseReceiver.ACTION_RESP);
		filter.addCategory(Intent.CATEGORY_DEFAULT);
		receiver = new ResponseReceiver();
		registerReceiver(receiver, filter);
		t1 = new TextToSpeech(getApplicationContext(),
				new TextToSpeech.OnInitListener() {
					@Override
					public void onInit(int status) {
						if (status != TextToSpeech.ERROR) {
							t1.setLanguage(Locale.UK);
						}
					}
				});
		// set a custom shadow that overlays the main content when the drawer
		// opens
		mDrawerLayout.setDrawerShadow(R.drawable.drawer_shadow,
				GravityCompat.START);
		// set up the drawer's list view with items and click listener
		mDrawerList.setAdapter(new ArrayAdapter<String>(this,
				R.layout.drawer_list_item, mPlanetTitles));
		mDrawerList.setOnItemClickListener(new DrawerItemClickListener());
		setinpause = false;
		drawerclose = false;
		// enable ActionBar app icon to behave as action to toggle nav drawer
		getActionBar().setDisplayHomeAsUpEnabled(true);
		getActionBar().setHomeButtonEnabled(true);

		// ActionBarDrawerToggle ties together the the proper interactions
		// between the sliding drawer and the action bar app icon
		mDrawerToggle = new ActionBarDrawerToggle(this, /* host Activity */
		mDrawerLayout, /* DrawerLayout object */
		R.drawable.ic_drawer, /* nav drawer image to replace 'Up' caret */
		R.string.drawer_open, /* "open drawer" description for accessibility */
		R.string.drawer_close /* "close drawer" description for accessibility */
		) {
			public void onDrawerClosed(View view) {
				drawerclose = true;

				getActionBar().setTitle(mTitle);
				invalidateOptionsMenu(); // creates call to
											// onPrepareOptionsMenu()
			}

			public void onDrawerOpened(View drawerView) {
				getActionBar().setTitle(mDrawerTitle);
				invalidateOptionsMenu(); // creates call to
											// onPrepareOptionsMenu()
			}
		};
		mDrawerLayout.setDrawerListener(mDrawerToggle);

		if (savedInstanceState == null) {
			selectItem(randomNumberInRange(0, 29));
		}
	}

	public static int randomNumberInRange(int min, int max) {
		Random random = new Random();
		return random.nextInt((max - min) + 1) + min;
	}

	@Override
	protected void onStop() {
		// TODO Auto-generated method stub
		super.onStop();

	}

	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		if (mediaPlayer != null && mediaPlayer.isPlaying()) {
			mediaPlayer.stop();
		}
		unregisterReceiver(receiver);
		super.onDestroy();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		MenuInflater inflater = getMenuInflater();
		inflater.inflate(R.menu.main, menu);
		return super.onCreateOptionsMenu(menu);
	}

	/* Called whenever we call invalidateOptionsMenu() */
	@Override
	public boolean onPrepareOptionsMenu(Menu menu) {
		// If the nav drawer is open, hide action items related to the content
		// view
		boolean drawerOpen = mDrawerLayout.isDrawerOpen(mDrawerList);
		menu.findItem(R.id.action_websearch).setVisible(!drawerOpen);
		return super.onPrepareOptionsMenu(menu);
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// The action bar home/up action should open or close the drawer.
		// ActionBarDrawerToggle will take care of this.
		if (mDrawerToggle.onOptionsItemSelected(item)) {
			return true;
		}
		// Handle action buttons
		switch (item.getItemId()) {
		case R.id.action_websearch:
			Intent sharingIntent = new Intent(
					android.content.Intent.ACTION_SEND);
			sharingIntent.setType("text/plain");
			String shareBody = "Here is the share content body";

			sharingIntent
					.putExtra(android.content.Intent.EXTRA_TEXT,
							"https://play.google.com/store/apps/details?id=kannada.bhava.geete");
			startActivity(Intent.createChooser(sharingIntent, "Share via"));
			return true;
		default:
			return super.onOptionsItemSelected(item);
		}
	}

	/* The click listner for ListView in the navigation drawer */
	private class DrawerItemClickListener implements
			ListView.OnItemClickListener {
		@Override
		public void onItemClick(AdapterView<?> parent, View view, int position,
				long id) {
			selectItem(position);
		}
	}

	private void selectItem(int position) {
		// update the main content by replacing fragments
		Fragment fragment = new PlanetFragment();
		Bundle args = new Bundle();
		args.putInt(PlanetFragment.ARG_PLANET_NUMBER, position);
		fragment.setArguments(args);

		FragmentManager fragmentManager = getFragmentManager();
		fragmentManager.beginTransaction()
				.replace(R.id.content_frame, fragment).commit();

		// update selected item and title, then close the drawer
		mDrawerList.setItemChecked(position, true);
		setTitle(mPlanetTitles[position]);
		mDrawerLayout.closeDrawer(mDrawerList);
	}

	@Override
	public void setTitle(CharSequence title) {
		if (getRandomBoolean() && drawerclose == true
				&& !title.equals("ಕನ್ನಡ ಭಕ್ತಿ ಗೀತೆಗಳು"))
			if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
				mInterstitialAd.show();
			}
		if (title.equals("ಕನ್ನಡ ಭಕ್ತಿ ಗೀತೆಗಳು")) {
			
			setinpause = false;

		}
		mTitle = title;
		getActionBar().setTitle(mTitle);
	}

	public boolean getRandomBoolean() {
		Random random = new Random();
		boolean temp = random.nextBoolean();
		return temp;
	}

	/**
	 * When using the ActionBarDrawerToggle, you must call it during
	 * onPostCreate() and onConfigurationChanged()...
	 */

	@Override
	protected void onPostCreate(Bundle savedInstanceState) {
		super.onPostCreate(savedInstanceState);
		// Sync the toggle state after onRestoreInstanceState has occurred.
		mDrawerLayout.openDrawer(mDrawerList);

		mDrawerToggle.syncState();
	}

	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
		if (setinpause)
		selectItem(randomNumberInRange(0, 29));

	}

	@Override
	public void onConfigurationChanged(Configuration newConfig) {
		super.onConfigurationChanged(newConfig);
		// Pass any configuration change to the drawer toggls
		mDrawerToggle.onConfigurationChanged(newConfig);
	}

	/**
	 * Fragment that appears in the "content_frame", shows a planet
	 */
	public static class PlanetFragment extends Fragment {
		public static final String ARG_PLANET_NUMBER = "planet_number";
		int i;
		ListView list;

		Integer[] imageId;
		ImageButton pre, playpause, next;
		TextView rhymname;
		TextView lyrics;
		int rhymepos = 0;
		int rhymepo3 = 0;

		int[] resrhymes = { R.raw.duddu_kottare_bekadu,
				R.raw.badavanadare_yenu_priye, R.raw.punnakoit,
				R.raw.bhagyada_balegara_hogi_baa, R.raw.ello_hudukide,
				R.raw.amma_ninna_edeyaaladalli,
				R.raw.kaanada_kadalige_hambaliside_mana, R.raw.kodaga_koli,
				R.raw.moodala_maneya_muttina_neerina, R.raw.ambiga_na_ninna,
				R.raw.jogada_siri, R.raw.nee_hinga_nodabyada,
				R.raw.vishwa_vinoothana, R.raw.raayaru_bandaru,
				R.raw.doni_saagali, R.raw.badaku_jataka_bhandi, R.raw.o_nanna,

				R.raw.chellidaro_malligeya, R.raw.deepavu_ninnade,
				R.raw.thera_yeri, R.raw.nimbiya_manada_myagala,
				R.raw.hindustanavu, R.raw.olithu, R.raw.thingaalu_mulugidavo,
				R.raw.taravalla_tangi, R.raw.yaake_badidadthi,
				R.raw.negila_hidida, R.raw.yello_jogappa,
				R.raw.ede_tumbi_hadidenu, R.raw.thavaroora_mane_noda_bande };

		String[] rhymesnames = { "ಪ�?ಣ�?ಯಕೋಟಿಯ ಕಥೆಯಿದ�?",
				"ಬಾರಿಸ�? ಕನ�?ನಡ ಡಿಂಡಿಮವ", "ಭಾಗ�?ಯದ ಬಳೆಗಾರ",
				"ಎಲ�?ಲೋ ಹ�?ಡ�?ಕಿದೆ ಇಲ�?ಲದ ದೇವರ", "ಹಚ�?ಚೇವ�? ಕನ�?ನಡದ ದೀಪ",
				"ಕಾಣದ ಕಡಲಿಗೆ ಹಂಬಲಿಸಿದೆ ಮನ", "ಕೋಡಗನ ಕೋಳಿ ನ�?ಂಗಿತ�?ತಾ",
				"ಮೂಡಲ ಮನೆಯಾ ಮ�?ತ�?ತಿನ ನೀರಿನ", };

		String[] rhymeslyrics = {
				"ಧರಣಿಮಂಡಲ ಮಧ�?ಯದೊಳಗೆ ಮೆರೆಯ�?ತಿಹ ಕರ�?ನಾಟ ದೇಶದೊ ಳಿರ�?ವ ಕಾಳಿಂಗನೆಂಬ ಗೊಲ�?ಲನ ಪರಿಯನೆಂತ�? ಪೇಳ�?ವೆನೊ ಗೊಲ�?ಲ ದೊಡ�?ಡಿಯಲಿರ�?ವ ಪಶ�?ಗಳ ಎಲ�?ಲ ಬೆಟ�?ಟದ ಮೇಲೆ ಮೇಯ�?ತ ಹ�?ಲ�?ಲ�?ವೊಳ�?ಳೆ ನೀರ�?ಗಳಿಂದಲೆ ಅಲ�?ಲಿ ಮೆರೆದವರಣ�?ಯದಿ ಎಳೆಯ ಮಾವಿನ ಮರದ ಕೆಳಗೆ ಕೊಳಲನೂದ�?ತ ಗೊಲ�?ಲ ಗೌಡನ�? ಬಳಸಿ ನಿಂದ ತ�?ರ�?ಗಳನ�?ನ�? ಬಳಿಗೆ ಕರೆದನ�? ಹರ�?ಷದಿ ಗಂಗೆ ಬಾರೆ ಗೌರಿ ಬಾರೆ ತ�?ಂಗಭದ�?ರೆ ತಾಯಿ ಬಾರೆ ಪ�?ಣ�?ಯಕೋಟಿ ನೀನ�? ಬಾರೆ ಎಂದ�? ಗೊಲ�?ಲನ�? ಕರೆದನ�? ಗೊಲ�?ಲ ಕರೆದಾ ದನಿಯ ಕೇಳಿ ಎಲ�?ಲ ಹಸ�?ಗಳ�? ಬಂದ�? ನಿಂದ�? ಚೆಲ�?ಲಿ ಸೂಸಿ ಹಾಲ�? ಕರೆಯಲ�? ಅಲ�?ಲಿ ತ�?ಂಬಿತ�? ಬಿಂದಿಗೆ ಹಬ�?ಬಿದಾಮಲೆ ಮಧ�?ಯದೊಳಗೆ ಅರ�?ಭ�?ತಾನೆಂದೆಂಬ ವ�?ಯಾಘ�?ರನ�? ಅಬ�?ಬರಿಸಿ ಹಸಿಹಸಿದ�? ಬೆಟ�?ಟದ ಕಿಬ�?ಬಿಯಾಳ�? ತಾನಿದ�?ದನ�? ಸಿಡಿದ�? ರೋಷದಿ ಗ�?ಡ�?ಗ�?ತಾ ಹ�?ಲಿ ಘ�?ಡ�?ಘ�?ಡಿಸಿ ಭೋರಿಡ�?ತವ�?ಯಾಘ�?ರನ�? ತ�?ಡ�?ಕಿ ಎರಗಿದ ರಭಸ ಕೇಳಿ ಓಡಿಹೋದವ�? ಹಸ�?ಗಳ�? ತನ�?ನ ಮಗನಾ ಪಡೆದ ಪಶ�?ವ�? ತನ�?ನ ಕಂದನ ನೆನೆದ�?ಕೊಂಡ�? ಪ�?ಣ�?ಯಕೋಟಿಯೆಂಬ ಹಸ�?ವ�? ಚೆಂದದಿಂದ ತಾ ಬರ�?ತಿರೆ ಇಂದೆನಗೆ ಆಹಾರ ಸಿಕ�?ಕಿತ�? ಎಂದ�? ಬೇಗನೆ ದ�?ಷ�?ಟ ವ�?ಯಾಘ�?ರನ�? ಬಂದ�? ಬಳಸಿ ಅಡ�?ಡಗಟ�?ಟಿ ನಿಂದನಾ ಹ�?ಲಿರಾಯನ�? ಮೇಲೆ ಬಿದ�?ದ�? ನಿನ�?ನನೀಗಲೆ ಬೀಳಹೊಯ�?ವೆನ�? ನಿನ�?ನ ಹೊಟ�?ಟೆಯ ಸೀಳಿಬಿಡ�?ವೆನ�? ಎನ�?ತ ಕೋಪದಿ ಖೂಳವ�?ಯಾಘ�?ರನ�? ಕೂಗಲ�? ಒಂದ�? ಬಿನ�?ನಹ ಹ�?ಲಿಯೆ ಕೇಳ�? ಕಂದನಿರ�?ವನ�? ದೊಡ�?ಡಿಯಾಳಗೆ ಒಂದ�? ನಿಮಿಷದಿ ಮೊಲೆಯ ಕೊಟ�?ಟ�? ಬಂದ�? ಸೇರ�?ವೆನಿಲ�?ಲಿಗೆ ಹಸಿದವೇಳೆಗೆ ಸಿಕ�?ಕಿದೊಡವೆಯ ವಶವ ಮಾಡದೆ ಬಿಡಲ�? ನೀನ�? ನ�?ಸ�?ಳಿ ಹೋಗ�?ವೆ ಮತ�?ತೆ ಬರ�?ವೆಯ ಹ�?ಸಿಯ ನ�?ಡಿಯ�?ವೆನೆಂದಿತ�? ಸತ�?ಯವೆ ನಮ�?ಮ ತಾಯಿ ತಂದೆ ಸತ�?ಯವೆ ನಮ�?ಮ ಬಂಧ�? ಬಳಗ ಸತ�?ಯವಾಕ�?ಯಕೆ ತಪ�?ಪಿ ನಡೆದರೆ ಮೆಚ�?ಚನಾ ಪರಮಾತ�?ಮನ�? ಕೊಂದ�? ತಿನ�?ನ�?ವೆನೆಂಬ ಹ�?ಲಿಗೆ ಚಂದದಿಂದ ಭಾಷೆಕೊಟ�?ಟ�? ಕಂದ ನಿನ�?ನನ�? ನೋಡಿ ಪೋಗ�?ವೆ ನೆಂದ�? ಬಂದಿತ�? ದೊಡ�?ಡಿಗೆ ಅಮ�?ಮ ನೀನ�? ಸಾಯಲೇಕೆ ನಮ�?ಮ ತಬ�?ಬಲಿ ಮಾಡಲೇಕೆ ಸ�?ಮ�?ಮನಿಲ�?ಲಿಯೆ ನಿಲ�?ಲ�? ಎಂದ�? ಅಮ�?ಮನಿಗೆ ಕರ�? ಹೇಳಿತ�? ಆರ ಮೊಲೆಯನ�? ಕ�?ಡಿಯಲಮ�?ಮ ಆರ ಬಳಿಯಲಿ ಮಲಗಲಮ�?ಮ ಆರ ಸೇರಿ ಬದ�?ಕಲಮ�?ಮ ಆರ�? ನನಗೆ ಹಿತವರ�? ಕೊಟ�?ಟ ಭಾಷೆಯ ತಪ�?ಪಲಾರೆನ�? ಕೆಟ�?ಟ ಯೋಚನೆ ಮಾಡಲಾರೆನ�? ನಿಷ�?ಠೆಯಿಂದಲಿ ಪೋಪೆನಲ�?ಲಿಗೆ ಕಟ�?ಟ ಕಡೆಗಿದ�? ಖಂಡಿತಾ ಅಮ�?ಮಗಳಿರ ಅಕ�?ಕಗಳಿರ ಎನ�?ನ ತಾಯಾಡಹ�?ಟ�?ಟ�?ಗಳಿರಾ ಕಂದ ನಿಮ�?ಮವನೆಂದ�? ಕಾಣಿರಿ ತಬ�?ಬಲಿಯನೀ ಕರ�?ವನೂ ಮ�?ಂದೆ ಬಂದರೆ ಹಾಯಬೇಡಿ ಹಿಂದೆ ಬಂದರೆ ವೊದೆಯಬೇಡಿ ಕಂದ ನಿಮ�?ಮವನೆಂದ�? ಕಾಣಿರಿ ತಬ�?ಬಲಿಯನೀ ಕರ�?ವನೂ ತಬ�?ಬಲಿಯ�? ನೀನಾದೆ ಮಗನೆ ಹೆಬ�?ಬ�?ಲಿಯ ಬಾಯನ�?ನ�? ಹೊಗ�?ವೆನ�? ಇಬ�?ಬರಾ ಋಣ ತೀರಿತೆಂದ�? ತಬ�?ಬಿಕೊಂಡಿತ�? ಕಂದನಾ ಗೋವ�? ಸ�?ನಾನವ ಮಾಡಿಕೊಂಡ�? ಗವಿಯಬಾಗಿಲ ಸೇರಿನಿಂತ�? ಸಾವಕಾಶವ ಮಾಡದಂತೆ ತವಕದಲಿ ಹ�?ಲಿಗೆಂದಿತ�? ಖಂಡವಿದೆಕೋ ಮಾಂಸವಿದೆಕೋ ಗ�?ಂಡಿಗೆಯ ಬಿಸಿರಕ�?ತವಿದೆಕೋ ಚಂಡವ�?ಯಾಘ�?ರನೆ ನೀನಿದೆಲ�?ಲವ ನ�?ಂಡ�? ಸಂತಸದಿಂದಿರ�? ಪ�?ಣ�?ಯಕೋಟಿಯ ಮಾತಕೇಳಿ ಕಣ�?ಣನೀರನ�? ಸ�?ರಿಸಿ ನೊಂದೂ ಕನ�?ನೆಯಿವಳನ�? ಕೊಂದ�? ತಿಂದರೆ ಮೆಚ�?ಚನಾ ಪರಮಾತ�?ಮನೂ ಎನ�?ನವೊಡಹ�?ಟ�?ಟಿದಕ�?ಕ ನೀನ�? ನಿನ�?ನ ಕೊಂದ�? �?ನ ಪಡೆವೆನ�? ಅನ�?ನೆಕಾರಿ ನಾನ�? ಎನ�?ತಲಿ ತನ�?ನ ಮನದೊಳ�? ನೊಂದಿತ�? ಮೂರ�?ಮೂರ�?ತಿಗೆ ಕೈಯಮ�?ಗಿದ�? ಸೇರಿ ಎಂಟ�?ದಿಕ�?ಕ�? ನೋಡಿ ಹಾರಿ ಆಕಾಶಕ�?ಕೆ ನೆಗೆದ�? ಮೀರಿ ಪ�?ರಾಣವ ಬಿಟ�?ಟಿತೂ",
				"ಬಾರಿಸ�? ಕನ�?ನಡ ಡಿಂಡಿಮವ \nಓ ಕರ�?ನಾಟಕ ಹೃದಯ ಶಿವ\n\nಬಾರಿಸ�? ಕನ�?ನಡ ಡಿಂಡಿಮವ\n\nಸತ�?ತಂತಿಹರನ�? ಬಡಿದೆಚ�?ಚರಿಸ�?\nಕಚ�?ಚಾಡ�?ವರನ�? ಕೂಡಿಸಿ ಒಲಿಸ�?\nಹೊಟ�?ಟೆಯ ಕಿಚ�?ಚಿಗೆ ಕಣ�?ಣೀರ�? ಸ�?ರಿಸ�?\nಒಟ�?ಟಿಗೆ ಬಾಳ�?ವ ತೆರದಲಿ ಹರಸ�?\n\nಬಾರಿಸ�? ಕನ�?ನಡ ಡಿಂಡಿಮವ ||\n\nಚೈತ ಶಿವೇತರ ಕೃತಿ ಕೃತಿಯಲ�?ಲಿ\nಮೂಡಲಿ ಮಂಗಳ ಮತಿ ಮತಿಯಲ�?ಲಿ\nಕವಿ ಋಷಿ ಸಂತರ ಆದರ�?ಶದಲಿ\nಸರ�?ವೋದಯವಾಗಲಿ ಸರ�?ವರಲಿ\n\nಬಾರಿಸ�? ಕನ�?ನಡ ಡಿಂಡಿಮವ ||",
				"ಭಾಗ�?ಯದ ಬಳೆಗಾರ ಹೋಗಿ ಬಾ ನನ�? ತವರೀಗೇ\nಭಾಗ�?ಯದ ಬಳೆಗಾರ ಹೋಗಿ ಬಾ ನನ�? ತವರೀಗೇ\nಭಾಗ�?ಯದ ಬಳೆಗಾರ ಹೋಗಿ ಬಾ ನನ�? ತವರೀಗೇ\nಭಾಗ�?ಯದ ಬಳೆಗಾರ ಹೋಗಿ ಬಾ ನನ�? ತವರೀಗೇ\n\nನಿನ�?ನ ತವರೂರಾ ನಾನೇನ�? ಬಲ�?ಲೆನ�?\nನಿನ�?ನ ತವರೂರಾ ನಾನೇನ�? ಬಲ�?ಲೆನ�?\nಗೋತ�?ತಿಲ�?ಲ ಎನಗೆ ಗ�?ರಿಯಿಲ�?ಲ ಎಲೆಬಾಲೆ\nಗೋತ�?ತಿಲ�?ಲ ಎನಗೆ ಗ�?ರಿಯಿಲ�?ಲ ಎಲೆಬಾಲೆ\nತೋರಿಸ�? ಬಾರೆ ತವರೂರ\n\nಭಾಗ�?ಯದ ಬಳೆಗಾರ ಹೋಗಿ ಬಾ ನನ�? ತವರೀಗೇ\nಭಾಗ�?ಯದ ಬಳೆಗಾರ ಹೋಗಿ ಬಾ ನನ�? ತವರೀಗೇ\n\nಬಾಳೆ ಬಲಕ�?ಕೆ ಬೀಡ�? ಸೀಬೆ ಎಡಕ�?ಕೆ ಬೀಡ�?\nಬಾಳೆ ಬಲಕ�?ಕೆ ಬೀಡ�? ಸೀಬೆ ಎಡಕ�?ಕೆ ಬೀಡ�?\nನಟ�?ಟ ನಡ�?ವೇಲ�?ಲಿ ನೀ ಹೋಗ�? ಬಳೆಗಾರ\nನಟ�?ಟ ನಡ�?ವೇಲ�?ಲಿ ನೀ ಹೋಗ�? ಬಳೆಗಾರ\nಅಲ�?ಲಿಹ�?ದೆನ�?ನಾ ತವರೂರ�?\n\nಮ�?ತ�?ತೈದೆ ಎಲೆ ಹೆಣ�?ಣೆ ತೋರ�? ಬಾ ನಿನ�?ನ ತವರೂರಾ\nಮ�?ತ�?ತೈದೆ ಎಲೆ ಹೆಣ�?ಣೆ ತೋರ�? ಬಾ ನಿನ�?ನ ತವರೂರಾ\n\nಹಂಚಿನಾ ಮನೆ ಕಾಣೋ ಕಂಚಿನಾ ಕದ ಕಾಣೋ\nಹಂಚಿನಾ ಮನೆ ಕಾಣೋ ಕಂಚಿನಾ ಕದ ಕಾಣೋ\nಇಂಚಾಡೋವೆರಡ�? ಗಿಳಿ ಕಾಣೋ ಬಳೆಗಾರ\nಅಲ�?ಲಿಹ�?ದೆನ�?ನಾ ತವರೂರ�?\n\nಮ�?ತ�?ತೈದೆ ಎಲೆ ಹೆಣ�?ಣೆ ತೋರ�? ಬಾ ನಿನ�?ನ ತವರೂರಾ\nಮ�?ತ�?ತೈದೆ ಎಲೆ ಹೆಣ�?ಣೆ ತೋರ�? ಬಾ ನಿನ�?ನ ತವರೂರಾ\n\nಆಲೆ ಆಡ�?ತ�?ತಾವೇ ಗಾಣ ತಿರ�?ಗ�?ತ�?ತಾವೇ\nಆಲೆ ಆಡ�?ತ�?ತಾವೇ ಗಾಣ ತಿರ�?ಗ�?ತ�?ತಾವೇ\nನವಿಲ�? ಸಾರಂಗ ನಲಿದಾವೇ ಬಳೆಗಾರ\nಅಲ�?ಲಿಹ�?ದೆನ�?ನಾ ತವರೂರ�?\n\nಮ�?ತ�?ತೈದೆ ಎಲೆ ಹೆಣ�?ಣೆ ತೋರ�? ಬಾ ನಿನ�?ನ ತವರೂರಾ\nಮ�?ತ�?ತೈದೆ ಎಲೆ ಹೆಣ�?ಣೆ ತೋರ�? ಬಾ ನಿನ�?ನ ತವರೂರಾ\n\nಮ�?ತ�?ತೈದೆ ಹಟ�?ಟೀಲಿ ಮ�?ತ�?ತಿನ ಚಪ�?ರಾಹಾಸಿ\nಮ�?ತ�?ತೈದೆ ಹಟ�?ಟೀಲಿ ಮ�?ತ�?ತಿನ ಚಪ�?ರಾಹಾಸಿ\nನಟ�?ಟ ನಡ�?ವೇಲ�?ಲಿ ಪಗಡೆಯ ಆಡ�?ತ�?ತಾಳೆ\nನಟ�?ಟ ನಡ�?ವೇಲ�?ಲಿ ಪಗಡೆಯ ಆಡ�?ತ�?ತಾಳೆ\nಅವಳೆ ಕಣೋ ನನ�?ನ ಹಡೆದವ�?ವ\n\nಮ�?ತ�?ತೈದೆ ಎಲೆ ಹೆಣ�?ಣೆ ತೋರ�? ಬಾ ನಿನ�?ನ ತವರೂರಾ\nಮ�?ತ�?ತೈದೆ ಎಲೆ ಹೆಣ�?ಣೆ ತೋರ�? ಬಾ ನಿನ�?ನ ತವರೂರಾ\n\nಅಚ�?ಚ ಕೆಂಪಿನ ಬಳೆ,ಹಸಿರ�? ಗೀರಿನ ಬಳೆ\nಅಚ�?ಚ ಕೆಂಪಿನ ಬಳೆ,ಹಸಿರ�? ಗೀರಿನ ಬಳೆ\nನನ�?ನ ಹಡೆದವ�?ವಗೆ ಬಲ�? ಆಸೆ ಬಳೆಗಾರ\nನನ�?ನ ಹಡೆದವ�?ವಗೆ ಬಲ�? ಆಸೆ ಬಳೆಗಾರ\nಕೊಂಡ�? ಹೋಗೊ ನನ�?ನ ತವರೀಗೆ\n\nಭಾಗ�?ಯದ ಬಳೆಗಾರ ಹೋಗಿ ಬಾ ನನ�? ತವರೀಗೇ\nಭಾಗ�?ಯದ ಬಳೆಗಾರ ಹೋಗಿ ಬಾ ನನ�? ತವರೀಗೇ\nಭಾಗ�?ಯದ ಬಳೆಗಾರ ಹೋಗಿ ಬಾ ನನ�? ತವರೀಗೇ\nಭಾಗ�?ಯದ ಬಳೆಗಾರ ಹೋಗಿ ಬಾ ನನ�? ತವರೀಗೇ",
				"ಎಲ�?ಲೋ ಹ�?ಡ�?ಕಿದೆ ಇಲ�?ಲದ ದೇವರ\nಕಲ�?ಲ�? ಮಣ�?ಣ�?ಗಳ ಗ�?ಡಿಯೊಳಗೆ\nಇಲ�?ಲೇ ಇರ�?ವ ಪ�?ರೀತಿ ಸ�?ನೇಹಗಳ\nಗ�?ರ�?ತಿಸದಾದೆವ�? ನಮ�?ಮೊಳಗೆ || ಎಲ�?ಲೋ ||\n\nಎಲ�?ಲಿದೆ ನಂದನ ಎಲ�?ಲಿದೆ ಬಂಧನ\nಎಲ�?ಲಾ ಇವೆ ಈ ನಮ�?ಮೊಳಗೆ\nಒಳಗಿನ ತಿಳಿಯನ�? ಕಲಕದೆ ಇದ�?ದರೆ\nಅಮೃತದ ಸವಿಯಿದೆ ನಾಲಗೆಗೆ || ಎಲ�?ಲೋ ||\nಹತ�?ತಿರವಿದ�?ದೂ ದೂರ ನಿಲ�?ಲ�?ವೆವ�?\nನಮ�?ಮ ಅಹಂಮಿನ ಕೋಟೆಯಲಿ\nಎಷ�?ಟ�? ಕಷ�?ಟವೋ ಹೊಂದಿಕೆಯೆಂಬ�?ದ�?\nನಾಲ�?ಕ�? ದಿನದ ಈ ಬದ�?ಕಿನಲ�?ಲಿ || ಎಲ�?ಲೋ ||",
				"ಹಚ�?ಚೇವ�? ಕನ�?ನಡದ ದೀಪ\nಕರ�?ನಾಡ ದೀಪ ಸಿರಿನ�?ಡಿಯ ದೀಪ\nಒಲವೆತ�?ತಿ ತೋರ�?ವ ದೀಪ\n\nಬಹ�?ದಿನಗಳಿಂದ ಮೈಮರೆವೆಯಿಂದ\nಕೂಡಿರ�?ವ ಕೊಳೆಯ ಕೊಚ�?ಚೇವ�?\nಎಲ�?ಲೆಲ�?ಲಿ ಕನ�?ನಡದ ಕಂಪ�? ಸೂಸಲ�?\nಅಲ�?ಲಲ�?ಲಿ ಕರಣ ಚಾಚೇವ�?\nನಡ�?ನಾಡೆ ಇರಲಿ ಗಡಿನಾಡೆ ಇರಲಿ\nಕನ�?ನಡದ ಕಳೆಯ ಕೆಚ�?ಚೇವ�?\nಮರೆತೇವ�? ಮರವ ತೆರೆದೇವ�? ಮನವ\nಎರೆದೇವ�? ಒಲವ ಹಿರಿನೆನಪಾ\nನರನರವನೆಲ�?ಲ ಹ�?ರಿಗೊಳಿಸಿ ಹೊಸದ�? ಹಚ�?ಚೇವ�? ಕನ�?ನಡದ ದೀಪ.\n\nಕಲ�?ಪನೆಯ ಕಣ�?ಣ�? ಹರಿವನಕ ಸಾಲ�?\nದೀಪಗಳ ಬೆಳಕ ಬೀರೇವ�?\nಹಚ�?ಚಿರ�?ವ ದೀಪದಲಿ ತಾಯರೂಪ\nಅಚ�?ಚಳಿಯದಂತೆ ತೋರೇವ�?\nಒಡಲೊಳಲ ಕೆಚ�?ಚಿನ ಕಿಡಿಗಳನ�?ನ�?\nಗಡಿನಾಡಿನಾಚೆ ತೂರೇವ�?\nಹೊಮ�?ಮಿರಲ�? ಪ�?ರೀತಿ ಎಲ�?ಲಿನದ�? ಭೀತಿ\nನಾಡೊಲವೆ ನೀತಿ ಹಿಡಿನೆನಪಾ\nಮನೆಮನೆಗಳಲ�?ಲಿ ಮನಮನಗಳಲ�?ಲಿ ಹಚ�?ಚೇವ�? ಕನ�?ನಡದ ದೀಪ.\n\nನಮ�?ಮವರ�? ಗಳಿಸಿದ ಹೆಸರ�?ಳಿಸಲ�?\nಎಲ�?ಲಾರ�? ಒಂದ�?ಗೂಡೇವ�?\nನಮ�?ಮೆದೆಯ ಮಿಡಿಯ�?ವೀ ಮಾತಿನಲ�?ಲಿ\nಮಾತೆಯನ�? ಪೂಜೆಮಾಡೇವ�?\nನಮ�?ಮ�?ಸಿರ�? ತೀಡ�?ವೀ ನಾಡಿನಲ�?ಲಿ\nಮಾಂಗಲ�?ಯಗೀತ ಹಾಡೇವ�?\nತೊರೆದೇವ�? ಮರ�?ಳ ಕಡೆದೇವ�? ಇರ�?ಳ\nಪಡೆದೇವ�? ತಿರ�?ಳ ಹಿರಿನೆನಪಾ\nಕರ�?ಳೆಂಬ ಕ�?ಡಿಗೆ ಮಿಂಚನ�?ನೆ ಮ�?ಡಿಸಿ ಹಚ�?ಚೇವ�? ಕನ�?ನಡದ ದೀಪ",
				"ಕಾಣದ ಕಡಲಿಗೆ ಹಂಬಲಿಸಿದೆ ಮನ, ಮನ…\nಕಾಣದ ಕಡಲಿಗೆ ಹಂಬಲಿಸಿದೆ ಮನ\nಕಾಣದ ಕಡಲಿಗೆ ಹಂಬಲಿಸಿದೆ ಮನ\nಕಾಣಬಲ�?ಲೆನೆ ಒಂದ�? ದಿನ\n\nಕಡಲನ�? ಕೂಡಬಲ�?ಲೆನೆ ಒಂದ�? ದಿನ\nಕಾಣಬಲ�?ಲೆನೆ ಒಂದ�? ದಿನ\nಕಡಲನ�? ಕೂಡಬಲ�?ಲೆನೆ ಒಂದ�? ದಿನ\n\nಕಾಣದ ಕಡಲಿಗೆ ಹಂಬಲಿಸಿದೆ ಮನ ||\n \nಕಾಣದ ಕಡಲಿನ ಮೊರೆತದ ಜೋಗ�?ಳ\n\nಒಳಗಿವಿಗಿಂದ�? ಕೇಳ�?ತಿದೆ\n\nಕಾಣದ ಕಡಲಿನ ಮೊರೆತದ ಜೋಗ�?ಳ\n\nಒಳಗಿವಿಗಿಂದ�? ಕೇಳ�?ತಿದೆ\n\nನನ�?ನ ಕಲ�?ಪನೆಯ�? ತನ�?ನ ಕಡಲನೆ\n\nಚಿತ�?ರಿಸಿ ಚಿಂತಿಸಿ ಸ�?ಯ�?ಯ�?ತಿದೆ\n\nಎಲ�?ಲಿರ�?ವ�?ದೋ ಅದ�? ಎಂತಿರ�?ವ�?ದೋ ಅದ�?\n\nನೋಡಬಲ�?ಲೆನೆ ಒಂದ�? ದಿನ\n\nಕಡಲನ�? ಕೂಡಬಲ�?ಲೆನೆ ಒಂದ�? ದಿನ ॥೧॥\nಕಾಣದ ಕಡಲಿಗೆ ಹಂಬಲಿಸಿದೆ ಮನ.\n \nಸಾವಿರ ಹೊಳೆಗಳ�? ತ�?ಂಬಿ ಹರಿದರೂ\n\nಒಂದೇ ಸಮನಾಗಿಹ�?ದಂತೆ\nಸಾವಿರ ಹೊಳೆಗಳ�? ತ�?ಂಬಿ ಹರಿದರೂ\n\nಒಂದೇ ಸಮನಾಗಿಹ�?ದಂತೆ\nಸ�?ನೀಲ ವಿಸ�?ತರ ತರಂಗ ಶೋಭಿತ\n\nಗಂಭೀರಾಂಬ�?ಧಿ ತಾನಂತೆ\n\nಮ�?ನ�?ನೀರಂತೆ, ಅಪಾರವಂತೆ,\nಕಾಣಬಲ�?ಲೆನೆ ಒಂದ�? ದಿನ\n\nಅದರೊಳ�? ಕರಗಲಾರೆನೆ ಒಂದ�? ದಿನ  ॥೨॥\nಕಾಣದ ಕಡಲಿಗೆ ಹಂಬಲಿಸಿದೆ ಮನ.\nಜಟಿಲ ಕಾನನದ ಕ�?ಟಿಲ ಪಥಗಳಲಿ\nಹರಿವ ತೊರೆಯ�? ನಾನ�?\n\nಎಂದಿಗಾದರ�?, ಎಂದಿಗಾದರ�?, ಎಂದಿಗಾದರೂ\n\nಕಾಣದ ಕಡಲನ�? ಸೇರಬಲ�?ಲೆನೇನ�?\nಜಟಿಲ ಕಾನನದ ಕ�?ಟಿಲ ಪಥಗಳಲಿ\n\nಹರಿವ ತೊರೆಯ�? ನಾನ�?\nಎಂದಿಗಾದರ�? ಕಾಣದ ಕಡಲನ�? ಸೇರಬಲ�?ಲೆನೇನ�?\nಸೇರಬಹ�?ದೇ ನಾನ�?, ಕಡಲ ನೀಲಿಯೊಳ�? ಕರಗಬಹ�?ದೆ ನಾನ�?\n\nಕರಗಬಹ�?ದೆ ನಾನ�?, ಕರಗಬಹ�?ದೆ ನಾನ�?",
				"ಕೋಡಗನ ಕೋಳಿ ನ�?ಂಗಿತ�?ತಾ\nನೋಡವ�?ವ ತಂಗಿ\nಕೋಡಗನ ಕೋಳಿ ನ�?ಂಗಿತ�?ತಾ ||ಪ||\n\nಆಡ�? ಆನೆಯ ನ�?ಂಗಿ\nಗೋಡೆ ಸ�?ಣ�?ಣವ ನ�?ಂಗಿ\nಆಡಲ�? ಬಂದ ಪಾತರದವಳ ಮದ�?ದಲಿ ನ�?ಂಗಿತ�?ತಾ, ತಂಗಿ  ||೧ ||\n \nಒಳ�?ಳ�? ಒನಕೆಯ ನ�?ಂಗಿ\nಕಲ�?ಲ�? ಗೂಟವ ನ�?ಂಗಿ\nಮೆಲ�?ಲಲ�? ಬಂದ ಮ�?ದ�?ಕಿಯನ�?ನೇ ಮೆಲ�?ಲ�? ನ�?ಂಗಿತ�?ತಾ, ತಂಗಿ ||೨ ||\n\nಹಗ�?ಗ ಮಗ�?ಗವ ನ�?ಂಗಿ\nಮಗ�?ಗವ  ಲಾಳಿ ನ�?ಂಗಿ\nಮಗ�?ಗದಲಿರ�?ವ ಅಣ�?ಣನನ�?ನೇ ಮಣಿಯ�? ನ�?ಂಗಿತ�?ತಾ, ತಂಗಿ ||೩ ||\n\nಗ�?ಡ�?ಡ ಗವಿಯನ�?ನ�? ನ�?ಂಗಿ\nಗವಿಯ�? ಇರ�?ವೆಯ ನ�?ಂಗಿ\nಗೋವಿಂದ ಗ�?ರ�?ವಿನ ಪಾದ ನನ�?ನನೆ ನ�?ಂಗಿತ�?ತಾ, ತಂಗಿ ||೪ ||",
				"ಮೂಡಲ ಮನೆಯಾ ಮ�?ತ�?ತಿನ ನೀರಿನ\nಎರಕವ ಹೊಯ�?ದಾ\nನ�?ಣ�?ಣ�?-ನ�?ನೆರಕsವ ಹೊಯ�?ದಾ\nಬಾಗಿಲ ತೆರೆದೂ ಬೆಳಕ�? ಹರಿದೂ\nಜಗವೆಲ�?ಲಾ ತೊಯ�?ದಾ\nಹೋಯ�?ತೋ-ಜಗವೆಲ�?ಲಾತೊಯ�?ದಾ\n\nರತ�?ನದರಸದಾ ಕಾರಂಜೀಯೂ\nಪ�?ಟಪ�?ಟನೇ ಪ�?ಟಿದ�?\nತಾನೇ-ಪ�?ಟಪ�?ಟನೇ ಪ�?ಟಿದ�?\nಮಘಮಘಿಸ�?ವಾ ಮ�?ಗಿದ ಮೊಗ�?ಗೀ\nಪಟಪಟನೇ ಒಡೆದ�?\nತಾನೇ-ಪಟಪಟನೇ ಒಡೆದ�?\n\nಎಲೆಗಳ ಮೇಲೇ ಹೂಗಳ ಒಳಗೇ\nಅಮೃತsದ ಬಿಂದ�?\nಕಂದವ�?-ಅಮೃತsದ ಬಿಂದ�?\nಯಾರಿರಿಸಿದವರ�? ಮ�?ಗಿಲsಮೇಲಿಂ-\nದಿಲ�?ಲಿಗೇ ತಂದ�?\nಈಗ -ಇಲ�?ಲಿಗೇ ತಂದ�?\n\nತಂಗಾಳೀಯ ಕೈಯೊಳಗಿರಿಸೀ\nಎಸಳೀನಾ ಚವರೀ\nಹೂವಿನ-ಎಸಳೀನಾ ಚವರಿ\nಹಾರಿಸಿ ಬಿಟ�?ಟರ�? ತ�?ಂಬಿಯ ದಂಡ�?\nಮೈಯೆಲ�?ಲಾ ಸವರಿ\nಗಂಧಾ-ಮೈಯೆಲ�?ಲಾ ಸವರಿ\n\nಗಿಡಗಂಟೆಯಾ ಕೊರಳೊಳಗಿಂದ\nಹಕ�?ಕಿಗಲಾ ಹಾಡ�?\nಹೊರಟಿತ�?-ಹಕ�?ಕಿಗಳಾ ಹಾಡ�?\nಗಂಧರ�?ವರಾ ಸೀಮೆಯಾಯಿತ�?\nಕಾಡಿನಾ ನಾಡ�?\nಕ�?ಷಣದೊಳ�?-ಕಾಡಿನಾ ನಾಡ�?.\n\nಕಂಡಿತ�? ಕಣ�?ಣ�? ಸವಿದಿತ�? ನಾಲಗೆ\nಪಡೆದೀತೀ ದೇಹ\nಸ�?ಪರ�?ಶಾ-ಪಡೆದೀತೀ ದೇಹ\nಕೇಳಿತ�? ಕಿವಿಯ�? ಮೂಸಿತ�? ಮೂಗ�?\nತನ�?ಮಯವೀ ಗೇಹಾ\nದೇವರ-ದೀ ಮನಸಿನ ಗೇಹಾ\nಅರಿಯದ�? ಅಳವ�? ತಿಳಿಯದ�? ಮನವ�?\nಕಾಣsದೋ ಬಣ�?ಣ\nಕಣ�?ಣಿದೆ-ಕಾಣsದೋ ಬಣ�?ಣ\nಶಾಂತಿರಸವೇ ಪ�?ರೀತಿಯಿಂದಾ\nಮೈದೋರಿತಣ�?ಣ\nಇದ�? ಬರಿ-ಬೆಳಗಲ�?ಲೋ ಅಣ�?ಣಾ" };

		public PlanetFragment() {
			// Empty constructor required for fragment subclasses
		}

		int currentPos;

		@Override
		public View onCreateView(LayoutInflater inflater, ViewGroup container,
				Bundle savedInstanceState) {
			View rootView = null;
			i = getArguments().getInt(ARG_PLANET_NUMBER);

			rootView = inflater.inflate(R.layout.rhymes, container, false);
			// AdView mAdView = (AdView) rootView.findViewById(R.id.adView);
			// AdRequest adRequest = new AdRequest.Builder().build();

			// AdRequest adRequest = new AdRequest.Builder().addTestDevice(
			// "827C83CB6F95569F1AA8385F8BCC4BD1") // An example device
			// ID
			// .build();
			// mAdView.loadAd(adRequest);

			AdView mAdView = (AdView) rootView.findViewById(R.id.adView);
			AdRequest adRequest = new AdRequest.Builder().build();

			// AdRequest adRequest = new AdRequest.Builder().addTestDevice(
			// "827C83CB6F95569F1AA8385F8BCC4BD1") // An example device
			// ID
			// .build();
			mAdView.loadAd(adRequest);
			mInterstitialAd = new InterstitialAd(rootView.getContext());
			mInterstitialAd
					.setAdUnitId("ca-app-pub-7605970282562833/1218079064");
			// mInterstitialAd
			// .setAdUnitId("ca-app-pub-7605970282562833/8289891906");

			AdRequest interstitialadRequest = new AdRequest.Builder().build();

			mInterstitialAd.loadAd(interstitialadRequest);

			CustomList adapter = null;
			if (mediaPlayer != null && mediaPlayer.isPlaying()) {
				mediaPlayer.stop();
			}
			switch (i) {
			case 0:
				rhymepos = 0;

				break;
			case 1:
				rhymepos = 1;

				break;
			case 2:
				rhymepos = 2;

				break;

			case 3:
				rhymepos = 3;

				break;
			case 4:
				rhymepos = 4;

				break;
			case 5:
				rhymepos = 5;

				break;
			case 6:
				rhymepos = 6;

				break;
			case 7:
				rhymepos = 7;

				break;
			case 8:
				rhymepos = 8;

				break;
			case 9:
				rhymepos = 9;

				break;
			case 10:
				rhymepos = 10;

				break;
			case 11:
				rhymepos = 11;

				break;
			case 12:
				rhymepos = 12;

				break;
			case 13:
				rhymepos = 13;

				break;
			case 14:
				rhymepos = 14;

				break;
			case 15:
				rhymepos = 15;

				break;
			case 16:
				rhymepos = 16;
				break;
			case 17:
				rhymepos = 17;
				break;
			case 18:
				rhymepos = 18;

				break;

			case 19:
				rhymepos = 19;

				break;
			case 20:
				rhymepos = 20;

				break;
			case 21:
				rhymepos = 21;

				break;
			case 22:
				rhymepos = 22;

				break;
			case 23:
				rhymepos = 23;

				break;
			case 24:
				rhymepos = 24;

				break;
			case 25:
				rhymepos = 25;

				break;
			case 26:
				rhymepos = 26;

				break;
			case 27:
				rhymepos = 27;

				break;
			case 28:
				rhymepos = 28;

				break;
			case 29:
				rhymepos = 29;

				break;
			case 30:
				try {
					if (mediaPlayer != null && mediaPlayer.isPlaying()) {
						mediaPlayer.stop();
						mediaPlayer.release();
						mediaPlayer = null;

					}
				} catch (Exception e) {

				}
				startActivity(new Intent(
						Intent.ACTION_VIEW,
						Uri.parse("https://play.google.com/store/apps/details?id=god.bhagwan.bhajans.mantra.kannada")));

				break;
			case 31:
				try {
					if (mediaPlayer != null && mediaPlayer.isPlaying()) {
						mediaPlayer.stop();
						mediaPlayer.release();
						mediaPlayer = null;

					}
				} catch (Exception e) {

				}
				startActivity(new Intent(
						Intent.ACTION_VIEW,
						Uri.parse("https://play.google.com/store/apps/details?id=god.bhagwan.bhajans.mantra.kannada")));

				break;

			}
			/*
			 * int i = getArguments().getInt(ARG_PLANET_NUMBER); String planet =
			 * getResources().getStringArray(R.array.planets_array)[i];
			 * 
			 * int imageId =
			 * getResources().getIdentifier(planet.toLowerCase(Locale
			 * .getDefault()), "drawable", getActivity().getPackageName());
			 * ((ImageView)
			 * rootView.findViewById(R.id.image)).setImageResource(imageId);
			 * getActivity().setTitle(planet);
			 */

			pre = (ImageButton) rootView.findViewById(R.id.prv);
			pre = (ImageButton) rootView.findViewById(R.id.prv);

			pre.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					lyrics.setVisibility(v.VISIBLE);

					rhymepos--;
					if (rhymepos < 0) {
						rhymepos = resrhymes.length - 1;
					}
					playRhyme(rhymepos);

				}
			});
			playpause = (ImageButton) rootView.findViewById(R.id.playpause);
			rhymname = (TextView) rootView.findViewById(R.id.text);
			lyrics = (TextView) rootView.findViewById(R.id.lyrics);

			playpause.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					PauseRhyme();
				}
			});
			next = (ImageButton) rootView.findViewById(R.id.next);
			next.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					lyrics.setVisibility(v.VISIBLE);

					rhymepos++;
					if (rhymepos >= resrhymes.length) {
						rhymepos = 0;
					}
					playRhyme(rhymepos);

				}
			});
			playRhyme(rhymepos);

			return rootView;
		}

		void playRhyme(int position) {
			lyrics.setVisibility(View.VISIBLE);

			if (mediaPlayer != null && mediaPlayer.isPlaying()) {
				mediaPlayer.stop();
			}
			rhymname.setText(getResources().getStringArray(
					R.array.planets_array)[position]);
			lyrics.setText(getResources().getStringArray(R.array.rhymeslyrics)[position]);

			mediaPlayer = MediaPlayer.create(getActivity().getBaseContext(),
					resrhymes[position]);

			mediaPlayer.start();

			mediaPlayer
					.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
						public void onCompletion(MediaPlayer mp) {
							// finish current activity
							playNext();
						}
					});

		}

		void PauseRhyme() {
			if (mediaPlayer != null && mediaPlayer.isPlaying()) {
				mediaPlayer.pause();
				playpause.setImageResource(R.drawable.play);
			} else if (mediaPlayer != null) {

				mediaPlayer = MediaPlayer.create(
						getActivity().getBaseContext(), resrhymes[rhymepos]);
				playpause.setImageResource(R.drawable.pause);

				mediaPlayer.start();

			}

		}

		void playNext() {

			rhymepos++;
			if (rhymepos >= resrhymes.length) {
				rhymepos = 0;
			}

			playRhyme(rhymepos);

		}
	}
}