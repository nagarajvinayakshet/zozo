package kannada.bhava.geete;


import kannada.bhava.geete.R;
import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;

public class CustomList extends ArrayAdapter<String> {

	private final Activity context;
	private final String[] web;
	private final Integer[] imageId;

	public CustomList(Activity context, String[] web, Integer[] imageId) {
		super(context, R.layout.list_single, web);
		this.context = context;
		this.web = web;
		this.imageId = imageId;

	}

	@Override
	public View getView(int position, View view, ViewGroup parent) {
		LayoutInflater inflater = context.getLayoutInflater();
		View rowView = null;
		if (true) {
			rowView = inflater.inflate(R.layout.list_single, null, true);
			TextView txtTitle = (TextView) rowView.findViewById(R.id.txt);

			ImageView imageView = (ImageView) rowView.findViewById(R.id.img);
			txtTitle.setText(web[position]);
			imageView.setImageResource(imageId[position]);
		} else {
			rowView = inflater.inflate(R.layout.list_single_ad, null, true);
			AdView mAdView = (AdView) rowView.findViewById(R.id.adView);
			AdRequest adRequest = new AdRequest.Builder().build();

			//AdRequest adRequest = new AdRequest.Builder().addTestDevice(
				//	"827C83CB6F95569F1AA8385F8BCC4BD1") // An example device ID
					//.build();
			mAdView.loadAd(adRequest);

		}

		return rowView;
	}
}