/** Automatically generated file. DO NOT MODIFY */
package kannada.bhava.geete;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}