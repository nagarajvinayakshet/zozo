/*
 * Copyright 2013 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package god.bhagwan.bhajans.mantra;

import java.util.Random;

import android.app.Activity;
import android.app.Fragment;
import android.app.FragmentManager;
import android.content.Intent;
import android.content.res.Configuration;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.ActionBarDrawerToggle;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;

/**
 * This example illustrates a common usage of the DrawerLayout widget in the
 * Android support library.
 * <p/>
 * <p>
 * When a navigation (left) drawer is present, the host activity should detect
 * presses of the action bar's Up affordance as a signal to open and close the
 * navigation drawer. The ActionBarDrawerToggle facilitates this behavior. Items
 * within the drawer should fall into one of two categories:
 * </p>
 * <p/>
 * <ul>
 * <li><strong>View switches</strong>. A view switch follows the same basic
 * policies as list or tab navigation in that a view switch does not create
 * navigation history. This pattern should only be used at the root activity of
 * a task, leaving some form of Up navigation active for activities further down
 * the navigation hierarchy.</li>
 * <li><strong>Selective Up</strong>. The drawer allows the user to choose an
 * alternate parent for Up navigation. This allows a user to jump across an
 * app's navigation hierarchy at will. The application should treat this as it
 * treats Up navigation from a different task, replacing the current task stack
 * using TaskStackBuilder or similar. This is the only form of navigation drawer
 * that should be used outside of the root activity of a task.</li>
 * </ul>
 * <p/>
 * <p>
 * Right side drawers should be used for actions, not navigation. This follows
 * the pattern established by the Action Bar that navigation should be to the
 * left and actions to the right. An action should be an operation performed on
 * the current contents of the window, for example enabling or disabling a data
 * overlay on top of the current content.
 * </p>
 */
public class MainActivity extends Activity {
	private DrawerLayout mDrawerLayout;
	private ListView mDrawerList;
	private ActionBarDrawerToggle mDrawerToggle;

	private CharSequence mDrawerTitle;
	private CharSequence mTitle;
	private String[] mPlanetTitles;
	static MediaPlayer mediaPlayer;
	private static InterstitialAd mInterstitialAd;
	private boolean setinpause;
	static boolean drawerclose;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		mTitle = mDrawerTitle = getTitle();
		mPlanetTitles = getResources().getStringArray(R.array.planets_array);
		mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
		mDrawerList = (ListView) findViewById(R.id.left_drawer);

		// set a custom shadow that overlays the main content when the drawer
		// opens
		mDrawerLayout.setDrawerShadow(R.drawable.drawer_shadow,
				GravityCompat.START);
		// set up the drawer's list view with items and click listener
		mDrawerList.setAdapter(new ArrayAdapter<String>(this,
				R.layout.drawer_list_item, mPlanetTitles));
		mDrawerList.setOnItemClickListener(new DrawerItemClickListener());
		setinpause = false;
		drawerclose = false;
		// enable ActionBar app icon to behave as action to toggle nav drawer
		getActionBar().setDisplayHomeAsUpEnabled(true);
		getActionBar().setHomeButtonEnabled(true);

		// ActionBarDrawerToggle ties together the the proper interactions
		// between the sliding drawer and the action bar app icon
		mDrawerToggle = new ActionBarDrawerToggle(this, /* host Activity */
		mDrawerLayout, /* DrawerLayout object */
		R.drawable.ic_drawer, /* nav drawer image to replace 'Up' caret */
		R.string.drawer_open, /* "open drawer" description for accessibility */
		R.string.drawer_close /* "close drawer" description for accessibility */
		) {
			public void onDrawerClosed(View view) {
				drawerclose = true;

				getActionBar().setTitle(mTitle);
				invalidateOptionsMenu(); // creates call to
											// onPrepareOptionsMenu()
			}

			public void onDrawerOpened(View drawerView) {
				getActionBar().setTitle(mDrawerTitle);
				invalidateOptionsMenu(); // creates call to
											// onPrepareOptionsMenu()
			}
		};
		mDrawerLayout.setDrawerListener(mDrawerToggle);

		if (savedInstanceState == null) {
			selectItem(0);
		}
	}

	@Override
	protected void onStop() {
		// TODO Auto-generated method stub
		super.onStop();

	}

	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		try {
			if (mediaPlayer != null && mediaPlayer.isPlaying()) {
				mediaPlayer.stop();
				mediaPlayer.release();
				mediaPlayer = null;
			}
		} catch (Exception e) {

		}
		super.onDestroy();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		MenuInflater inflater = getMenuInflater();
		inflater.inflate(R.menu.main, menu);
		return super.onCreateOptionsMenu(menu);
	}

	/* Called whenever we call invalidateOptionsMenu() */
	@Override
	public boolean onPrepareOptionsMenu(Menu menu) {
		// If the nav drawer is open, hide action items related to the content
		// view
		boolean drawerOpen = mDrawerLayout.isDrawerOpen(mDrawerList);
		menu.findItem(R.id.action_websearch).setVisible(!drawerOpen);
		return super.onPrepareOptionsMenu(menu);
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// The action bar home/up action should open or close the drawer.
		// ActionBarDrawerToggle will take care of this.
		if (mDrawerToggle.onOptionsItemSelected(item)) {
			return true;
		}
		// Handle action buttons
		switch (item.getItemId()) {
		case R.id.action_websearch:
			Intent sharingIntent = new Intent(
					android.content.Intent.ACTION_SEND);
			sharingIntent.setType("text/plain");
			String shareBody = "Here is the share content body";

			sharingIntent
					.putExtra(android.content.Intent.EXTRA_TEXT,
							"https://play.google.com/store/apps/details?id=god.bhagwan.bhajans.mantra");
			startActivity(Intent.createChooser(sharingIntent, "Share via"));
			return true;
		default:
			return super.onOptionsItemSelected(item);
		}
	}

	/* The click listner for ListView in the navigation drawer */
	private class DrawerItemClickListener implements
			ListView.OnItemClickListener {
		@Override
		public void onItemClick(AdapterView<?> parent, View view, int position,
				long id) {
			selectItem(position);
		}
	}

	private void selectItem(int position) {
		// update the main content by replacing fragments
		Fragment fragment = new PlanetFragment();
		Bundle args = new Bundle();
		args.putInt(PlanetFragment.ARG_PLANET_NUMBER, position);
		fragment.setArguments(args);

		FragmentManager fragmentManager = getFragmentManager();
		fragmentManager.beginTransaction()
				.replace(R.id.content_frame, fragment).commit();

		// update selected item and title, then close the drawer
		mDrawerList.setItemChecked(position, true);
		setTitle(mPlanetTitles[position]);
		mDrawerLayout.closeDrawer(mDrawerList);
	}

	@Override
	public void setTitle(CharSequence title) {
		if (getRandomBoolean() && drawerclose == true
				&& !title.equals("Jai Matadi Bhajans with Lyrics"))
			if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
				mInterstitialAd.show();
			}
		if (title.equals("Jai Matadi Bhajans with Lyrics")) {
			setinpause = false;
		} else {
			setinpause = false;

		}
		mTitle = title;
		getActionBar().setTitle(mTitle);
	}

	public boolean getRandomBoolean() {
		Random random = new Random();
		boolean temp = random.nextBoolean();
		return temp;
	}

	/**
	 * When using the ActionBarDrawerToggle, you must call it during
	 * onPostCreate() and onConfigurationChanged()...
	 */

	@Override
	protected void onPostCreate(Bundle savedInstanceState) {
		super.onPostCreate(savedInstanceState);
		// Sync the toggle state after onRestoreInstanceState has occurred.
		mDrawerLayout.openDrawer(mDrawerList);

		mDrawerToggle.syncState();
	}

	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
		if (setinpause)
			selectItem(1);

	}

	@Override
	public void onConfigurationChanged(Configuration newConfig) {
		super.onConfigurationChanged(newConfig);
		// Pass any configuration change to the drawer toggls
		mDrawerToggle.onConfigurationChanged(newConfig);
	}

	/**
	 * Fragment that appears in the "content_frame", shows a planet
	 */
	public static class PlanetFragment extends Fragment {
		public static final String ARG_PLANET_NUMBER = "planet_number";
		int i;
		ListView list;

		ImageButton pre, playpause, next;
		ImageView rhyme;

		TextView rhymname;
		int rhymepos = 0;

		int[] resID = { R.raw.jay_ambe_gauri, R.raw.chalo_bulawa_aaya_hai,
				R.raw.bhakton_ko_darshan_de_gayi_devi,
				R.raw.nange_nange_paon_chal_aa_gaya,
				R.raw.tune_mujhe_bulaya_sherawaliyein };
		int[] resID1 = { R.raw.mahamrityunjaya, R.raw.om_jai_shiv_omkara };
		int[] resID2 = { R.raw.jay_ganapati_gajanan, R.raw.jay_ganesh_deva,
				R.raw.sukhkarta_dukhharta, R.raw.vakratunda_mahakaya };
		int[] resID3 = { R.raw.shree_hanuman_chalisa };
		int[] resID4 = { R.raw.hare_krishna, R.raw.maiyaa_yashoda,
				R.raw.jai_radha_madhav, R.raw.yashomati_nandan_ };
		int[] resID5 = { R.raw.gayatri_mantra };
		int[] resID6 = { R.raw.sai_ram_sai_shyam, R.raw.shridi_wale_saibaba };
		int[] resID7 = { R.raw.kabhi_ram_banake,
				R.raw.raghupati_raghav_raja_ram };

		int[] resID8 = { R.raw.vishnu_sahasranamam };

		String[] web1 = { "महामूर्तियुंजय मंत्र\nMahamrityunjaya Mantra",
				"ॐ जया शिव ओमकारा\nOm Jaya Shiv Omkara" };
		Integer[] imageId1 = { R.drawable.shiv6, R.drawable.shiv1 };

		String[] web2 = { "जय गणपति गजानन\nJai Ganapati Gajanana",
				"जय गणेश देव\nJai Ganesh Deva",
				"सुख कर्ता दूख हर्था\nSukhkarta Dukhharta",
				"वक्रतुंड महाकाया\nVakratunda Mahakaya" };
		Integer[] imageId2 = { R.drawable.ganesh1, R.drawable.ganesh2,
				R.drawable.ganesh3, R.drawable.ganesh4 };

		String[] web3 = { "हनुमान चालीसा\nHanuman Chalisa" };
		Integer[] imageId3 = { R.drawable.hanuman_chalisa

		};

		String[] web4 = { "हरे कृष्ण, हरे राम\nHare Krisha, Hare Rama",
				"माया यशोदा\nMaiyaa Yashoda", "जय राधा माधव\nJai Radha Madhav",
				"यशो माता नंदन\nYashomati Nandan" };
		String[] web5 = { "गायत्री मंत्र\nGayatri Mantra" };
		String[] web6 = { "साईं राम साईं श्याम\nSai Ram Sai Shyam",
				"Shirdi Wale Saibaba" };
		String[] web7 = { "कही राम बांके\nKabhi Ram Banake",
				"रघुपति राघव राजा राम\nRaghupati Raghav Raja Ram" };
		String[] web8 = { "विष्णु साहसरामम\nVishnu Sahasranamam" };

		Integer[] imageId4 = { R.drawable.hare_krishna,
				R.drawable.maiyaa_yashoda, R.drawable.jai_radha_madhav,
				R.drawable.yashomati_nandan_

		};

		Integer[] imageId5 = { R.drawable.gayatri_mantra

		};
		Integer[] imageId6 = { R.drawable.sai1, R.drawable.sai2

		};
		Integer[] imageId7 = { R.drawable.ram6, R.drawable.ram9

		};
		Integer[] imageId8 = { R.drawable.vishnu1

		};

		String[] web = { "जय अंबे गौरी\nJay Ambe Gouri",
				"चलो बुलवा आया है\nChalo Bulawa Aaya Hai",
				"भक्तन को दर्शन दे गई देवी\nBhakton Ko Darshan De Gayi Devi",
				"नंगे नंगे पाव चल आ गया\nNange Nange Paon Chal Aa Gaya",
				"तूने मुझे बुलाया शेरावालिये\nTuni Mujhe Bulaya Sherawliye" };
		Integer[] imageId = { R.drawable.jmd5, R.drawable.jmd8,
				R.drawable.jmd1, R.drawable.jmd4, R.drawable.jmd7

		};

		public PlanetFragment() {
			// Empty constructor required for fragment subclasses
		}

		int currentPos;

		@Override
		public View onCreateView(LayoutInflater inflater, ViewGroup container,
				Bundle savedInstanceState) {
			View rootView = inflater.inflate(R.layout.fragment_planet,
					container, false);
			rootView = inflater.inflate(R.layout.rhymes, container, false);

			i = getArguments().getInt(ARG_PLANET_NUMBER);
			AdView mAdView = (AdView) rootView.findViewById(R.id.adView);
			AdRequest adRequest = new AdRequest.Builder().build();

			// AdRequest adRequest = new AdRequest.Builder().addTestDevice(
			// "827C83CB6F95569F1AA8385F8BCC4BD1") // An example device ID
			// .build();
			if (mAdView != null)
				mAdView.loadAd(adRequest);

			mInterstitialAd = new InterstitialAd(rootView.getContext());
			// mInterstitialAd
			// .setAdUnitId("ca-app-pub-7605970282562833/9211881909");
			mInterstitialAd
					.setAdUnitId("ca-app-pub-7605970282562833/9211881909");

			AdRequest interstitialadRequest = new AdRequest.Builder().build();

			mInterstitialAd.loadAd(interstitialadRequest);

			CustomList adapter = null;

			switch (i) {
			case 0:

				adapter = new CustomList(getActivity(), web, imageId);

				break;
			case 1:
				String[] web1 = { "Mahamrityunjaya Mantra",
						"Om Jaya Shiv Omkara" };
				Integer[] imageId1 = { R.drawable.shiv6, R.drawable.shiv1,

				};

				// adapter = new CustomList(getActivity(), web1, imageId1,l);

				break;
			case 2:

				String[] web2 = { "Jai Ganapati Gajanana", "Jai Ganesh Deva",
						"Sukhkarta Dukhharta", "Vakratunda Mahakaya",
						"Gajananam Gajavadanam" };
				Integer[] imageId2 = { R.drawable.ganesh1, R.drawable.ganesh2,
						R.drawable.ganesh3, R.drawable.ganesh4

				};

				// adapter = new CustomList(getActivity(), web2, imageId2);

				break;
			case 3:

				String[] web3 = { "Hanuman Chalisa" };
				Integer[] imageId3 = { R.drawable.hanuman_chalisa

				};

				// adapter = new CustomList(getActivity(), web3, imageId3);

				break;
			case 4:

				// adapter = new CustomList(getActivity(), web3, imageId3);

				break;
			case 5:

				// adapter = new CustomList(getActivity(), web3, imageId3);

				break;
			case 6:

				// adapter = new CustomList(getActivity(), web3, imageId3);

				break;
			case 7:

				// adapter = new CustomList(getActivity(), web3, imageId3);

				break;
			case 8:

				// adapter = new CustomList(getActivity(), web3, imageId3);

				break;
			case 9:
				try {
					if (mediaPlayer != null && mediaPlayer.isPlaying()) {
						mediaPlayer.stop();
						mediaPlayer.release();
					}
				} catch (Exception e) {

				}

				startActivity(new Intent(
						Intent.ACTION_VIEW,
						Uri.parse("https://play.google.com/store/apps/details?id=mata.durga.bhajan")));
				break;
			}
			/*
			 * int i = getArguments().getInt(ARG_PLANET_NUMBER); String planet =
			 * getResources().getStringArray(R.array.planets_array)[i];
			 * 
			 * int imageId =
			 * getResources().getIdentifier(planet.toLowerCase(Locale
			 * .getDefault()), "drawable", getActivity().getPackageName());
			 * ((ImageView)
			 * rootView.findViewById(R.id.image)).setImageResource(imageId);
			 * getActivity().setTitle(planet);
			 */
			/*
			 * list = (ListView) rootView.findViewById(R.id.list);
			 * list.setAdapter(adapter); list.setOnItemClickListener(new
			 * AdapterView.OnItemClickListener() {
			 * 
			 * @Override public void onItemClick(AdapterView<?> parent, View
			 * view, int position, long id) { currentPos = position;
			 * playSong(position); } });
			 */
			pre = (ImageButton) rootView.findViewById(R.id.prv);
			pre = (ImageButton) rootView.findViewById(R.id.prv);
			playpause = (ImageButton) rootView.findViewById(R.id.playpause);

			rhyme = (ImageView) rootView.findViewById(R.id.image);
			rhymname = (TextView) rootView.findViewById(R.id.text);
			pre.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {

					switch (i) {
					case 0:
						rhymepos--;
						if (rhymepos < 0) {
							rhymepos = resID.length - 1;
						}
						break;
					case 1:
						rhymepos--;
						if (rhymepos < 0) {
							rhymepos = resID1.length - 1;
						}
						break;
					case 2:
						rhymepos--;
						if (rhymepos < 0) {
							rhymepos = resID2.length - 1;
						}
						break;
					case 3:
						rhymepos--;
						if (rhymepos < 0) {
							rhymepos = resID3.length - 1;
						}
						break;
					case 4:
						rhymepos--;
						if (rhymepos < 0) {
							rhymepos = resID4.length - 1;
						}
						break;
					case 5:
						rhymepos--;
						if (rhymepos < 0) {
							rhymepos = resID5.length - 1;
						}
						break;
					case 6:
						rhymepos--;
						if (rhymepos < 0) {
							rhymepos = resID6.length - 1;
						}
						break;
					case 7:
						rhymepos--;
						if (rhymepos < 0) {
							rhymepos = resID7.length - 1;
						}
						break;
					case 8:
						rhymepos--;
						if (rhymepos < 0) {
							rhymepos = resID8.length - 1;
						}
						break;

					}

					playRhyme(rhymepos);
				}
			});

			playpause.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					PauseRhyme();
				}
			});

			next = (ImageButton) rootView.findViewById(R.id.next);
			next.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {

					switch (i) {
					case 0:
						rhymepos++;
						if (rhymepos >= resID.length) {
							rhymepos = 0;
						}
						break;
					case 1:
						rhymepos++;
						if (rhymepos >= resID1.length) {
							rhymepos = 0;
						}
						break;
					case 2:
						rhymepos++;
						if (rhymepos >= resID2.length) {
							rhymepos = 0;
						}
						break;
					case 3:
						rhymepos++;
						if (rhymepos >= resID3.length) {
							rhymepos = 0;
						}
						break;
					case 4:
						rhymepos++;
						if (rhymepos >= resID4.length) {
							rhymepos = 0;
						}
						break;
					case 5:
						rhymepos++;
						if (rhymepos >= resID5.length) {
							rhymepos = 0;
						}
					case 6:
						rhymepos++;
						if (rhymepos >= resID6.length) {
							rhymepos = 0;
						}
						break;
					case 7:
						rhymepos++;
						if (rhymepos >= resID7.length) {
							rhymepos = 0;
						}
						break;
					case 8:
						rhymepos++;
						if (rhymepos >= resID8.length) {
							rhymepos = 0;
						}
						break;
					}

					playRhyme(rhymepos);

				}
			});
			playRhyme(rhymepos);
			return rootView;
		}

		void playRhyme(int position) {
			try {
				if (mediaPlayer != null && mediaPlayer.isPlaying()) {
					mediaPlayer.stop();
					mediaPlayer.release();
					mediaPlayer = null;
				}
			} catch (Exception e) {
				mediaPlayer = null;
			}
			switch (i) {
			case 0:
				mediaPlayer = MediaPlayer.create(
						getActivity().getBaseContext(), resID[position]);
				rhyme.setImageResource(imageId[position]);

				rhymname.setText(web[rhymepos]);
				break;
			case 1:
				mediaPlayer = MediaPlayer.create(
						getActivity().getBaseContext(), resID1[position]);
				rhyme.setImageResource(imageId1[rhymepos]);

				rhymname.setText(web1[rhymepos]);
				break;
			case 2:
				mediaPlayer = MediaPlayer.create(
						getActivity().getBaseContext(), resID2[position]);
				rhyme.setImageResource(imageId2[rhymepos]);

				rhymname.setText(web2[rhymepos]);
				break;
			case 3:
				mediaPlayer = MediaPlayer.create(
						getActivity().getBaseContext(), resID3[position]);
				rhyme.setImageResource(imageId3[rhymepos]);

				rhymname.setText(web3[rhymepos]);
				break;
			case 4:
				mediaPlayer = MediaPlayer.create(
						getActivity().getBaseContext(), resID4[position]);
				rhyme.setImageResource(imageId4[rhymepos]);

				rhymname.setText(web4[rhymepos]);
				break;
			case 5:
				mediaPlayer = MediaPlayer.create(
						getActivity().getBaseContext(), resID5[position]);
				rhyme.setImageResource(imageId5[rhymepos]);
				rhymname.setText(web5[rhymepos]);

				break;
			case 6:
				mediaPlayer = MediaPlayer.create(
						getActivity().getBaseContext(), resID6[position]);
				rhyme.setImageResource(imageId6[rhymepos]);
				rhymname.setText(web6[rhymepos]);

				break;
			case 7:
				mediaPlayer = MediaPlayer.create(
						getActivity().getBaseContext(), resID7[position]);
				rhyme.setImageResource(imageId7[rhymepos]);
				rhymname.setText(web7[rhymepos]);

				break;
			case 8:
				mediaPlayer = MediaPlayer.create(
						getActivity().getBaseContext(), resID8[position]);
				rhyme.setImageResource(imageId8[rhymepos]);
				rhymname.setText(web8[rhymepos]);

				break;
			}
			if (mediaPlayer != null) {
				mediaPlayer.start();
				mediaPlayer
						.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
							public void onCompletion(MediaPlayer mp) {
								// finish current activity
								playNext();
							}
						});
			}
		}

		void PauseRhyme() {
			try {
				if (mediaPlayer != null && mediaPlayer.isPlaying()) {
					mediaPlayer.pause();
					playpause.setImageResource(R.drawable.play);
				} else if (mediaPlayer != null) {

					switch (i) {
					case 0:
						mediaPlayer = MediaPlayer.create(getActivity()
								.getBaseContext(), resID[rhymepos]);

						break;
					case 1:
						mediaPlayer = MediaPlayer.create(getActivity()
								.getBaseContext(), resID1[rhymepos]);

						break;
					case 2:
						mediaPlayer = MediaPlayer.create(getActivity()
								.getBaseContext(), resID2[rhymepos]);

						break;
					case 3:
						mediaPlayer = MediaPlayer.create(getActivity()
								.getBaseContext(), resID3[rhymepos]);

						break;
					case 4:
						mediaPlayer = MediaPlayer.create(getActivity()
								.getBaseContext(), resID4[rhymepos]);

						break;
					case 5:
						mediaPlayer = MediaPlayer.create(getActivity()
								.getBaseContext(), resID5[rhymepos]);

						break;
					case 6:
						mediaPlayer = MediaPlayer.create(getActivity()
								.getBaseContext(), resID6[rhymepos]);

						break;
					case 7:
						mediaPlayer = MediaPlayer.create(getActivity()
								.getBaseContext(), resID7[rhymepos]);

						break;
					case 8:
						mediaPlayer = MediaPlayer.create(getActivity()
								.getBaseContext(), resID8[rhymepos]);

						break;
					}
					playpause.setImageResource(R.drawable.pause);

					mediaPlayer.start();

				}
			} catch (Exception e) {

			}
		}

		void playSong(int position) {
			playpause.setImageResource(R.drawable.pause);
			try {
				if (mediaPlayer != null && mediaPlayer.isPlaying()) {
					mediaPlayer.stop();
					mediaPlayer.release();
					mediaPlayer = null;
				}
			} catch (Exception e) {

			}
			switch (i) {
			case 0:
				mediaPlayer = MediaPlayer.create(
						getActivity().getBaseContext(), resID[position]);
				break;
			case 1:
				mediaPlayer = MediaPlayer.create(
						getActivity().getBaseContext(), resID1[position]);
				break;
			case 2:
				mediaPlayer = MediaPlayer.create(
						getActivity().getBaseContext(), resID2[position]);
				break;
			case 3:
				mediaPlayer = MediaPlayer.create(
						getActivity().getBaseContext(), resID3[position]);
				break;
			case 4:
				mediaPlayer = MediaPlayer.create(
						getActivity().getBaseContext(), resID4[position]);
				break;
			case 5:
				mediaPlayer = MediaPlayer.create(
						getActivity().getBaseContext(), resID5[position]);
				break;
			case 6:
				mediaPlayer = MediaPlayer.create(
						getActivity().getBaseContext(), resID6[position]);
				break;
			case 7:
				mediaPlayer = MediaPlayer.create(
						getActivity().getBaseContext(), resID7[position]);
				break;
			case 8:
				mediaPlayer = MediaPlayer.create(
						getActivity().getBaseContext(), resID8[position]);
				break;
			}
			mediaPlayer.start();
		}

		void playNext() {
			switch (i) {
			case 0:
				rhymepos++;
				if (rhymepos >= resID.length) {
					rhymepos = 0;
				}
				break;
			case 1:
				rhymepos++;
				if (rhymepos >= resID1.length) {
					rhymepos = 0;
				}
				break;
			case 2:
				rhymepos++;
				if (rhymepos >= resID2.length) {
					rhymepos = 0;
				}
				break;
			case 3:
				rhymepos++;
				if (rhymepos >= resID3.length) {
					rhymepos = 0;
				}
				break;
			case 4:
				rhymepos++;
				if (rhymepos >= resID4.length) {
					rhymepos = 0;
				}
				break;
			case 5:
				rhymepos++;
				if (rhymepos >= resID5.length) {
					rhymepos = 0;
				}
			case 6:
				rhymepos++;
				if (rhymepos >= resID6.length) {
					rhymepos = 0;
				}
			case 7:
				rhymepos++;
				if (rhymepos >= resID7.length) {
					rhymepos = 0;
				}
			case 8:
				rhymepos++;
				if (rhymepos >= resID8.length) {
					rhymepos = 0;
				}
				break;

			}

			playRhyme(rhymepos);

		}

	}
}