/** Automatically generated file. DO NOT MODIFY */
package god.bhagwan.bhajans.mantra;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}